package type;

public abstract class Sorts {
    abstract void generateCommunicateRecord();
    abstract void printDetails();
}
