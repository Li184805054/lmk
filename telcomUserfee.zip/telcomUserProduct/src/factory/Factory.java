package factory;

public interface Factory {
    sorts createSorts();
}
